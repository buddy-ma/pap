<section class="blog-section bg-white-2 w-100">
    <div class="container">
        <div class="sec-title">
            <h2><span> Catalogue des </span>articles sur <?php echo e($ville->title); ?>.</h2>
        </div>
        <div class="news-wrap">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-md-6 col-xs-12">
                        <div class="news-item" data-aos="fade-up" data-aos-delay="200">
                            <a href="/blog/<?php echo e($blog->id); ?>" class="news-img-link">
                                <div class="news-item-img">
                                    <?php if(isset($blog->image)): ?>
                                        <img class="img-responsive" src="<?php echo e(asset('images/' . $blog->image)); ?>"
                                            alt="blog image">
                                    <?php else: ?>
                                        <img class="img-responsive" src="<?php echo e(asset('assets/images/blog/b-10.jpg')); ?>"
                                            alt="blog image">
                                    <?php endif; ?>
                                </div>
                            </a>
                            <div class="news-item-text">
                                <div class="dates">
                                    <span class="date">
                                        <?php echo e($blog->updated_at->translatedFormat('F j, Y')); ?>

                                    </span>
                                </div>
                                <a href="/blog/<?php echo e($blog->id); ?>">
                                    <h3><?php echo e($blog->title); ?></h3>
                                </a>

                                <div class="news-item-descr big-news">
                                    <?php
                                        $txt = strip_tags($blog->text);
                                        $txt = html_entity_decode($txt);
                                    ?>
                                    <p><?php echo e(substr($txt, 0, 170)); ?>... </p>
                                </div>
                                <div class="news-item-bottom">
                                    <a href="/blog/<?php echo e($blog->id); ?>" class="news-link">Read more...</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/resources/views/landing/decouvrezMaroc/villeBlogs.blade.php ENDPATH**/ ?>